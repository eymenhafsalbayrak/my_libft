﻿namespace Ders02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TXT_Girdi = new System.Windows.Forms.TextBox();
            this.BTN_Test = new System.Windows.Forms.Button();
            this.BTN_Bit = new System.Windows.Forms.Button();
            this.LBL_Cikti = new System.Windows.Forms.Label();
            this.BTN_bcd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TXT_Girdi
            // 
            this.TXT_Girdi.Location = new System.Drawing.Point(27, 14);
            this.TXT_Girdi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TXT_Girdi.Name = "TXT_Girdi";
            this.TXT_Girdi.Size = new System.Drawing.Size(453, 26);
            this.TXT_Girdi.TabIndex = 0;
            // 
            // BTN_Test
            // 
            this.BTN_Test.Location = new System.Drawing.Point(25, 72);
            this.BTN_Test.Name = "BTN_Test";
            this.BTN_Test.Size = new System.Drawing.Size(107, 30);
            this.BTN_Test.TabIndex = 1;
            this.BTN_Test.Text = "Ascii";
            this.BTN_Test.UseVisualStyleBackColor = true;
            this.BTN_Test.Click += new System.EventHandler(this.BTN_Test_Click);
            // 
            // BTN_Bit
            // 
            this.BTN_Bit.Location = new System.Drawing.Point(138, 72);
            this.BTN_Bit.Name = "BTN_Bit";
            this.BTN_Bit.Size = new System.Drawing.Size(107, 30);
            this.BTN_Bit.TabIndex = 2;
            this.BTN_Bit.Text = "Bit";
            this.BTN_Bit.UseVisualStyleBackColor = true;
            this.BTN_Bit.Click += new System.EventHandler(this.BTN_Bit_Click);
            // 
            // LBL_Cikti
            // 
            this.LBL_Cikti.AutoSize = true;
            this.LBL_Cikti.Location = new System.Drawing.Point(27, 49);
            this.LBL_Cikti.Name = "LBL_Cikti";
            this.LBL_Cikti.Size = new System.Drawing.Size(21, 20);
            this.LBL_Cikti.TabIndex = 3;
            this.LBL_Cikti.Text = "...";
            // 
            // BTN_bcd
            // 
            this.BTN_bcd.Location = new System.Drawing.Point(251, 72);
            this.BTN_bcd.Name = "BTN_bcd";
            this.BTN_bcd.Size = new System.Drawing.Size(107, 30);
            this.BTN_bcd.TabIndex = 4;
            this.BTN_bcd.Text = "BCD";
            this.BTN_bcd.UseVisualStyleBackColor = true;
            this.BTN_bcd.Click += new System.EventHandler(this.BTN_bcd_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 343);
            this.Controls.Add(this.BTN_bcd);
            this.Controls.Add(this.LBL_Cikti);
            this.Controls.Add(this.BTN_Bit);
            this.Controls.Add(this.BTN_Test);
            this.Controls.Add(this.TXT_Girdi);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXT_Girdi;
        private System.Windows.Forms.Button BTN_Test;
        private System.Windows.Forms.Button BTN_Bit;
        private System.Windows.Forms.Label LBL_Cikti;
        private System.Windows.Forms.Button BTN_bcd;
    }
}

