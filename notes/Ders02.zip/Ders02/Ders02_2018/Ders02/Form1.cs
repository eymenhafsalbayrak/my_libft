﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Ders02.sinif;

namespace Ders02
{
    public partial class Form1 : Form
    {
        Donusum _nesne;
        public Form1()
        {
            InitializeComponent();
            _nesne = new Donusum();
        }

        private void BTN_Test_Click(object sender, EventArgs e)
        {
            LBL_Cikti.Text = _nesne.ascii(TXT_Girdi.Text);
        }

        private void BTN_Bit_Click(object sender, EventArgs e)
        {    
            LBL_Cikti.Text = _nesne.ikili(TXT_Girdi.Text);
        }

        private void BTN_bcd_Click(object sender, EventArgs e)
        {
            LBL_Cikti.Text = _nesne.bcd(TXT_Girdi.Text);
        }
    }
}
