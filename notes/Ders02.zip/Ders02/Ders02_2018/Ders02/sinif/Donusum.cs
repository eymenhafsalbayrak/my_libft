﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders02.sinif
{
    public class Donusum
    {
        public string ikili(string input)
        {
            string temp = "";
            for (int i = 0; i < input.Length; i++)
                temp += " " + ikili((int)input[i], false);

            return temp;
        }

        public string ascii(string input)
        {
            string temp = "";
            for (int i = 0; i < input.Length; i++)
                temp += " " + (int)input[i];

            return temp;
        }

        public string bcd(string input)
        {
            string temp = "";
            for (int i = 0; i < input.Length; i++)
            {
                int teksayi = Convert.ToInt32(input[i].ToString());
                temp += " " + ikili(teksayi, true);
            }

            return temp;
        }

        private string ikili(int input, bool bcd)
        {
            string inner_temp = "";
            while (input > 1)
            {
                int kalan = input % 2;
                inner_temp += kalan.ToString();
                input = input / 2;
            }
            inner_temp += input.ToString();

            byte bitsayisi = 8;
            if (bcd)
                bitsayisi = 4;
            inner_temp = ters(inner_temp, bitsayisi);

            return inner_temp;
        }

        private string ters(string input, byte bitsayisi)
        {
            string temp = "";

            //eksik bit ekleme
            for (int i = input.Length; i < bitsayisi; i++)
                temp += "0";

            for (int i = input.Length - 1; i >= 0; i--)
                temp += input[i];

            return temp;
        }
    }
}
