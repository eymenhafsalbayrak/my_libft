﻿namespace Problem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TXT_Sayi1 = new System.Windows.Forms.TextBox();
            this.TXT_Sayi2 = new System.Windows.Forms.TextBox();
            this.LBL_Sonuc = new System.Windows.Forms.Label();
            this.BTN_Topla = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TXT_Sayi1
            // 
            this.TXT_Sayi1.Location = new System.Drawing.Point(67, 31);
            this.TXT_Sayi1.Name = "TXT_Sayi1";
            this.TXT_Sayi1.Size = new System.Drawing.Size(417, 26);
            this.TXT_Sayi1.TabIndex = 0;
            this.TXT_Sayi1.Text = "1";
            // 
            // TXT_Sayi2
            // 
            this.TXT_Sayi2.Location = new System.Drawing.Point(67, 63);
            this.TXT_Sayi2.Name = "TXT_Sayi2";
            this.TXT_Sayi2.Size = new System.Drawing.Size(417, 26);
            this.TXT_Sayi2.TabIndex = 1;
            this.TXT_Sayi2.Text = "12";
            // 
            // LBL_Sonuc
            // 
            this.LBL_Sonuc.AutoSize = true;
            this.LBL_Sonuc.Location = new System.Drawing.Point(63, 131);
            this.LBL_Sonuc.Name = "LBL_Sonuc";
            this.LBL_Sonuc.Size = new System.Drawing.Size(21, 20);
            this.LBL_Sonuc.TabIndex = 2;
            this.LBL_Sonuc.Text = "...";
            // 
            // BTN_Topla
            // 
            this.BTN_Topla.Location = new System.Drawing.Point(67, 95);
            this.BTN_Topla.Name = "BTN_Topla";
            this.BTN_Topla.Size = new System.Drawing.Size(75, 33);
            this.BTN_Topla.TabIndex = 3;
            this.BTN_Topla.Text = "Topla";
            this.BTN_Topla.UseVisualStyleBackColor = true;
            this.BTN_Topla.Click += new System.EventHandler(this.BTN_Topla_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 414);
            this.Controls.Add(this.BTN_Topla);
            this.Controls.Add(this.LBL_Sonuc);
            this.Controls.Add(this.TXT_Sayi2);
            this.Controls.Add(this.TXT_Sayi1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXT_Sayi1;
        private System.Windows.Forms.TextBox TXT_Sayi2;
        private System.Windows.Forms.Label LBL_Sonuc;
        private System.Windows.Forms.Button BTN_Topla;
    }
}

