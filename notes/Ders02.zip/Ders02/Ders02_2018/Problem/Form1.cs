﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Problem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BTN_Topla_Click(object sender, EventArgs e)
        {
            string sayi1 = TXT_Sayi1.Text;
            string sayi2 = TXT_Sayi2.Text;
            int basamak1 = sayi1.Length;
            int basamak2 = sayi2.Length;
            string ekle = "";
            if (basamak1 < basamak2)
            {
                for (int i = basamak1; i < basamak2; i++)
                    ekle += "0";
                sayi1 = ekle + sayi1;
            } else
            {
                for (int i = basamak2; i < basamak1; i++)
                    ekle += "0";
                sayi2 = ekle + sayi2;
            }

            string temp = "";
            int elde = 0;
            for (int i = sayi1.Length - 1; i >= 0; i--)
            {
                int s1 = Convert.ToInt16(sayi1[i].ToString());
                int s2 = Convert.ToInt16(sayi2[i].ToString());

                int s3 = s1 + s2 + elde;
                if (s3 >= 10)
                    elde = 1;
                else
                    elde = 0;

                temp += (s3 % 10).ToString();
            }

            string temp2 = "";
            for (int i = temp.Length - 1; i >= 0; i--)
                temp2 += temp[i];

            LBL_Sonuc.Text = temp2;                    
        }
    }
}
