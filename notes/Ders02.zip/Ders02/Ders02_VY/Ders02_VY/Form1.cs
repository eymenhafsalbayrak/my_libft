﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ders02_VY
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Dönüşüm sınıfı yaratılıyor.
            sinif.donusumler _d = new sinif.donusumler();
            label1.Text = _d.TumAsciiKarakter();           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sinif.donusumler _d = new sinif.donusumler();
            label2.Text = _d.BuyukHarf(textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sinif.donusumler _d = new sinif.donusumler();
            label2.Text = _d.KucukHarf(textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sinif.donusumler _d = new sinif.donusumler();
            label2.Text = _d.toAscii(textBox1.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sinif.donusumler _d = new sinif.donusumler();
            label2.Text = _d.toIkili(textBox1.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            sinif.donusumler _d = new sinif.donusumler();
            label2.Text = _d.toBCD(textBox1.Text);
        }
    }
}
