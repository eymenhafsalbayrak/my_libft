﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ders02_VY.sinif
{
    class donusumler
    {
        //255 adet ASCII karakteri bulup bir string içine yazan kod.
        public string TumAsciiKarakter()
        {
            string temp = "";

            for (int i = 1; i < 256; i++)
            {
                char y = (char)i;
                temp += " " + y;
            }

            return temp;
        }

        //Gelen harfler arasından küçük olanları büyüğe çeviren kod
        public string BuyukHarf(string temp)
        {
            int Buyuk_A = (int)'A';
            int Buyuk_Z = (int)'Z';
            int Kucuk_a = (int)'a';
            int Kucuk_z = (int)'z';
            int fark = Kucuk_a - Buyuk_A;
            string temp_sonuc = "";
            foreach (char kr in temp)
            {
                int temp_Asccii = (int)kr;
                //Harf küçük mü kontrolü. küçükse -32 ile büyük yapılıyor.
                if (temp_Asccii <= Kucuk_z && temp_Asccii >= Kucuk_a)
                {
                    temp_Asccii = temp_Asccii - 32;
                }

                temp_sonuc += (char)temp_Asccii;
            }

            return temp_sonuc;
        }

        //Gelen harfler arasından büyük olanları küçüğe çeviren kod
        public string KucukHarf(string temp)
        {
            int Buyuk_A = (int)'A';
            int Buyuk_Z = (int)'Z';
            int Kucuk_a = (int)'a';
            int Kucuk_z = (int)'z';
            int fark = Kucuk_a - Buyuk_A;
            string temp_sonuc = "";
            foreach (char kr in temp)
            {
                int temp_Asccii = (int)kr;
                //Harf büyük mü kontrolü. küçükse +32 ile küçük yapılıyor.
                if (temp_Asccii <= Buyuk_Z && temp_Asccii >= Buyuk_A)
                {
                    temp_Asccii = temp_Asccii + 32;
                }

                temp_sonuc += (char)temp_Asccii;
            }

            return temp_sonuc;
        }

        //ASCII sayısal değer ile girilen ifadeyi gösterme. Çıktı yine bir string.
        public string toAscii(string temp)
        {
            string temp_sonuc = "";
            foreach (char kr in temp)
            {
                int temp_Asccii = (int)kr;
                temp_sonuc += " " + temp_Asccii.ToString();
            }

            return temp_sonuc;
        }

        //İkili gösterim. Girilen karakterin ASCII karşılığının 0/1 duruma getirilmiş durumu. Çıktı yine string
        public string toIkili(string temp)
        {
            string temp_sonuc = "";
            foreach (char kr in temp)
            {
                int temp_Asccii = (int)kr;
                temp_sonuc += " " + ikiligosterim(temp_Asccii, 8); //8 bit
            }

            return temp_sonuc;
        }

        //4 veya 8 bitli gösterin. Verilen sayıyı bölerek kalan ve son bölüm sonuçlarını bulup, verilen bit sayısına uygun şekilde 0 ekleyip, 
        // terse çevirip binary karşılığı string türünden üreten kod. 
        private string ikiligosterim(int karakter, int bitsayisi)
        {
            string temp_sonuc = "";
            int bolum = karakter;
           
                while (true)
                {
                    //özel durumlar
                    if (karakter == 0)
                    {
                        temp_sonuc = "0";
                        break;
                    }
                    if (karakter == 1)
                    {
                        temp_sonuc = "1";
                        break;
                    }

                    int kalan = bolum % 2;
                    bolum = bolum / 2;
                    temp_sonuc += kalan;
                    if (bolum == 1)
                    {
                        temp_sonuc += bolum;
                        break;
                    }
                }


            //4 veya 8 bite tamamlama
            for (int i = temp_sonuc.Length; i < bitsayisi; i++)
            {
                temp_sonuc += "0";
            }

            //tersten görüntüleme
            string temp_sonuc2 = "";
            for (int i = temp_sonuc.Length-1; i >= 0; i--)
            {
                temp_sonuc2 += temp_sonuc[i].ToString();
            }

            return temp_sonuc2;
        }

        //4 bit şeklinde sadece sayısal değerleri gösterme. Sistem yine ASCII üzerinden çalışıyor. ama sayı değilse 1111 sayı ise sayı karşılığını bulup binary karşılığı yazılıyor.
        public string toBCD(string temp)
        {
            string temp_sonuc = "";
            foreach (char kr in temp)
            {
                 
                 if (SayiMi(kr))
                 {
                     int temp_Asccii = (int)kr;
                     int Sayi_0 = (int)'0';
                     int sayi = temp_Asccii - Sayi_0;
                     temp_sonuc += " " + ikiligosterim(sayi, 4); //4 bit 
                 }
                 else
                     temp_sonuc += " 1111"; 
            }

            return temp_sonuc;
        }

        //ASCII bir karakterin sayı mı değil mi kontrolünü yapan kod.
        public bool SayiMi(char temp)
        {
            int Sayi_0 = (int)'0';
            int Sayi_9 = (int)'9';
            if (temp >= Sayi_0 && temp <= Sayi_9)
                return true;
            else
                return false;
        }


    }
}
