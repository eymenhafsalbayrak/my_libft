﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Katar.sinif
{
    class katar
    {
        //Kelime Uzunluğunu bulan fonksiyon
        public int KelimeUzunluk(string temp)
        {
            int cnt = 0;
            foreach (char kr in temp)
                cnt++;
            
            return cnt;
        } //Aslında temp.Length ile durum çözülebilir. Ancak bu dersin amacı temel seviyede konuyu öğrenmektir.

        //Kelimeyi tersten yazan fonksiyon.
        public string KelimeTersten(string temp)
        {
            string sonuc = "";
            for (int i = KelimeUzunluk(temp)-1; i >= 0; i--)
            {
                sonuc += temp[i];               
            }

            return sonuc;
        }
    }
}
