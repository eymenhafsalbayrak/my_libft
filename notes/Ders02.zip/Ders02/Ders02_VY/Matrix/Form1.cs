﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Matrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double[,] array2D = new double[5, 5] { 
            { 0.0, 0.71, 5.66, 3.61, 4.24 }, 
            { 0.71, 0.0, 4.95, 2.92, 3.54 }, 
            { 5.66, 4.95, 0.0, 2.24, 1.41 }, 
            { 3.61, 2.92, 2.24, 0.0, 1.00 }, 
            { 4.24, 3.54, 1.41, 1.00, 0.0 } };
            textBox1.Text = "";
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    textBox1.Text += "   " + array2D[i, j].ToString("F");                                        
                }
                textBox1.Text += "\r\n";
            }

            //toplam
            double toplam = 0;
            int adim_sayisi = 0;
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 5; j++)
                {
                    toplam += array2D[i, j];
                    adim_sayisi++;
                }
                    

            textBox1.Text += "\r\n\r\n\r\n" + "Toplam: " + toplam.ToString() + " - Adım Sayısı: " + adim_sayisi;

            //iyileştirme 1
            toplam = 0;
            adim_sayisi = 0;
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 5; j++)
                {
                    if(i<j)
                    {
                        toplam += array2D[i, j];
                        adim_sayisi++;
                    }                    
                }

            textBox1.Text += "\r\n" + "Yeni Toplam: " + (toplam*2).ToString() + " - Adım Sayısı: " + adim_sayisi;

            //iyileştirme 2
            toplam = 0;
            adim_sayisi = 0;
            for (int i = 0; i < 5; i++)
                for (int j = i+1; j < 5; j++)
                {
                        toplam += array2D[i, j];
                        adim_sayisi++;
                }

            textBox1.Text += "\r\n" + "Yeni Toplam: " + (toplam * 2).ToString() + " - Adım Sayısı: " + adim_sayisi;
        }
    }
}
